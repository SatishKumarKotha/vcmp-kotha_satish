import mysql from "mysql2/promise";
import dotenv from "dotenv";

// ----load the dotenv config ------\\
dotenv.config();

//-----------creating a mysql pool connection -------------\\
const connectionPool =  mysql.createPool({
    host:process.env.DB_HOST,
    port:process.env.DB_PORT,
    user:process.env.DB_USER,
     password: process.env.DB_PASSWORD,
     database: process.env.DB_NAME,

     waitForConnections:true,
     connectionLimit:10,
     queueLimit:0
})
//-----------export the pool to connect with db ------------------\\ 
export default connectionPool;